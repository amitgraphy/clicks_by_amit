/*
  SITE CONTENT — edit this file to manage your website.
  You can edit it from a laptop, desktop, or phone using GitHub's web editor.
  Keep image URLs in quotes. To add a photo, copy one gallery object and change its fields.
*/
const SITE = {
  name: "Amit Photography",
  tagline: "Stories in Light",
  intro: "A curated collection of portraits, places and everyday moments captured with a quiet, timeless style.",
  about: "Photography for me is less about posing and more about noticing: the light, the expression, the place and the little details that become memories.",
  email: "your-email@example.com",
  categories: ["All","Portraits","Travel","Nature","Events"],
  gallery: [
    {title:"Golden Hour",category:"Portraits",location:"Auckland, New Zealand",image:"https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=1200&q=88"},
    {title:"Coastal Light",category:"Travel",location:"New Zealand",image:"https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=88"},
    {title:"Still Morning",category:"Nature",location:"Auckland",image:"https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1200&q=88"},
    {title:"The Journey",category:"Travel",location:"New Zealand",image:"https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=88"},
    {title:"Quiet Portrait",category:"Portraits",location:"Auckland",image:"https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=88"},
    {title:"After Rain",category:"Nature",location:"New Zealand",image:"https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=88"},
    {title:"Celebration",category:"Events",location:"Auckland",image:"https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=88"},
    {title:"Blue Horizon",category:"Travel",location:"North Island",image:"https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=88"},
    {title:"Forest Walk",category:"Nature",location:"Waikato",image:"https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1200&q=88"}
  ]
};